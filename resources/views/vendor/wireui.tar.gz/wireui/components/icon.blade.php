<x-dynamic-component component="wireui::icons.{{ $style }}.{{ $name }}" {{ $attributes }} />
